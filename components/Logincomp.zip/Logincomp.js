import React from 'react'
import { Button, Container, Form } from 'react-bootstrap'

export default function Logincomp() {
  return (
    <>
    <Container className='text-center'>
        <h1 className='text-center'>Login Page</h1>
        <Form className='text-center'>
         
            <input type='email' placeholder='Enter Email Id'/><br/>
            <input type='text' placeholder='Enter Password'/><br/>
            <Button type='submit'>Submit</Button>
        </Form>
    </Container>
    </>
  )
}
