import React from 'react'
import { Button, Container, Form } from 'react-bootstrap'

export default function Registercomp() {
  return (
    <>
    <Container className='text-center'>
    <h1 className='text-center'>Register Page</h1>
        <Form className='text-center'>
            <input type='text' placeholder='Enter Name'/><br/>
            <input type='text' placeholder='Enter Phone Number'/><br/>
            <input type='email' placeholder='Enter Email Id'/><br/>
            <input type='text' placeholder='Enter Password'/><br/>
            <input type='text' placeholder='Confirm Password'/><br/>
            <Button type='submit'>Submit</Button>
        </Form>
    </Container>
    </>
  )
}
