import React from 'react'

export default function About1({p1}) {
  return (
    <div>About1, {p1}</div>
  )
}
